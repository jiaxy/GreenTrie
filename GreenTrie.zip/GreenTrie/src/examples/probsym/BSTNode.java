package probsym;

public class BSTNode {
	public int value;

	public BSTNode left, right;

	public BSTNode(int x) {
		value = x;
		left = null;
		right = null;
	}

}