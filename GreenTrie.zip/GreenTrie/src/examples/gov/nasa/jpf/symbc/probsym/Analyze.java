package gov.nasa.jpf.symbc.probsym;

public class Analyze {

	public static void coverage(String string) {
		// TODO Auto-generated method stub
		System.out.println(string);
	}

}
