package gov.nasa.jpf.symbc;

public class TestUtils {
    native public static String getPathCondition();
    native public static String getSolvedPathCondition();
}
