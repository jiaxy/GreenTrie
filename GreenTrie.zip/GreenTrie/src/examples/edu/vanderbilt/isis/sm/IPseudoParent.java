package edu.vanderbilt.isis.sm;

public interface IPseudoParent {
	void addPseudoChild(Pseudostate p);
	boolean isState();
}
