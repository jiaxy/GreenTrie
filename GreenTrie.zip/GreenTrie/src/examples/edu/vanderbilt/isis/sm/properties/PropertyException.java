package edu.vanderbilt.isis.sm.properties;

public class PropertyException extends Exception {
}
