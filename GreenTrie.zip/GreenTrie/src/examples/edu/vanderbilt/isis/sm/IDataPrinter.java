package edu.vanderbilt.isis.sm;

import java.util.ArrayList;

public interface IDataPrinter {
	public void writeData(ArrayList<String> values);
}
