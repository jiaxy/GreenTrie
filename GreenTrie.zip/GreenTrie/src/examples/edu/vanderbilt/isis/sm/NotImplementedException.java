package edu.vanderbilt.isis.sm;

public class NotImplementedException extends Exception {
	public NotImplementedException() {
		super();
	}
	
	public NotImplementedException(String s) {
		super(s);
	}
}
